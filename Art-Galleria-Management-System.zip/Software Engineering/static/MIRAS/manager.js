$("#Add").on('click',function(e) {
    e.preventDefault();
    var med = $("#MedIDRestock").val();
    $("#MedIDRestock").val("");
    var quan= $("#QuantityRestock").val();
    $("#QuantityRestock").val("");
    // $('ul').append('<li class="list-group-item">' + med + "     " +'<span class="badge badge-primary badge-pill">' + quan +'</span>' +'</li>');  

    $.ajax({
        type: "POST",
        url: "/Add",
        contentType: 'application/json; charset=UTF-8',
        data: JSON.stringify({"med":med , "quan":quan}),
        success: function(data){
            $('table_med').html(data);
        }
    });
});

$("#Done").click(function(){
    alert("Medicine Successfully Restocked!");
    location.reload();
});

    // $("#Add").on("click", function(e) {
//     e.preventDefault();
//     var med = $("#MedIDRestock").val();
//     $("#MedIDRestock").val("");
//     var quan= $("#QuantityRestock").val();
//     $("#QuantityRestock").val("");
//     $('ul').append('<li class="list-group-item">' + med + "     " +'<span class="badge badge-primary badge-pill">' + quan +'</span>' +'</li>');  
// });

//  $("#Done").click(function(){
//   alert("Medicine Successfully Restocked!");
//   location.reload();
//  });